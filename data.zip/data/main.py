import pygame
import random

# Define constants for colors and window dimensions
BLACK = (0, 0, 0)
WINDOW_WIDTH = 500
WINDOW_HEIGHT = 500
NUM_BOMBS = 20
EXPLOSION_TIME = 500  # duration for which the explosion is shown in milliseconds
pygame.init()
window_surface = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption('Bomb Game')

# Load images
bomb_image = pygame.image.load("bomb.png")
explosion_image = pygame.image.load("explosion.png")

# Initialize bomb and explosion lists
bombs = []
explosions = []  # list to hold explosions

# Function to check if a newly placed bomb collides with existing bombs
def check_bomb_collision(x, y):
    for bomb in bombs:
        if abs(bomb[0] - x) < 50 and abs(bomb[1] - y) < 50:
            return True
    return False

# Function to check for expired explosions
def remove_expired_explosions(current_time):
    explosions[:] = [explosion for explosion in explosions if current_time - explosion[2] < EXPLOSION_TIME]

# Placement of bombs
while len(bombs) < NUM_BOMBS:
    x = random.randint(0, WINDOW_WIDTH - 50)
    y = random.randint(0, WINDOW_HEIGHT - 50)
    if not check_bomb_collision(x, y):
        bombs.append((x, y))

clock = pygame.time.Clock()
running = True

# Game loop
while running:
    # Get current time
    current_time = pygame.time.get_ticks()

    # Remove expired explosions
    remove_expired_explosions(current_time)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.MOUSEBUTTONUP:
            click_pos = pygame.mouse.get_pos()
            for i, (x, y) in enumerate(bombs):
                bomb_rect = pygame.Rect(x, y, 50, 50)
                if bomb_rect.collidepoint(click_pos):
                    # Replace bomb with explosion
                    explosions.append((x, y, current_time))
                    bombs.pop(i)
                    break

    # Draw black background
    window_surface.fill(BLACK)

    # Draw bombs
    for x, y in bombs:
        window_surface.blit(bomb_image, (x, y))

    # Draw explosions, only those that are not expired
    for x, y, _ in explosions:
        window_surface.blit(explosion_image, (x, y))

    # Update display
    pygame.display.flip()

    clock.tick(60)

pygame.quit()